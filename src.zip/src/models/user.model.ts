import { prop, getModelForClass, modelOptions, index } from "@typegoose/typegoose";

export const USER_ROLES = ["job_seeker", "employer"] as const;
export type UserRole = (typeof USER_ROLES)[number];

@modelOptions({
  schemaOptions: {
    timestamps: true,
    collection: "users",
  },
  options: { allowMixed: 0 },
})
@index({ email: 1 }, { unique: true }) // Unique email index
export class User {
  @prop({ required: true })
  name!: string;

  @prop({ required: true }) // Removed unique here to avoid duplicate index warning
  email!: string;

  @prop({ required: true })
  password!: string;

  @prop({ type: String, enum: USER_ROLES, default: "job_seeker" })
  role!: UserRole;

  @prop()
  resumeUrl?: string; // For job seekers

  @prop()
  companyName?: string; // For employers

  @prop()
  website?: string; // For employers
}

// Create the Mongoose model
export const UserModel = getModelForClass(User);
