import z, { object, string, TypeOf } from "zod";
import { USER_ROLES } from "../config/constansts";

export const createUserSchema = object({
  body: object({
    name: string().min(1, "Name is required"),
    email: string().email("Invalid email address"),
    password: string().min(6, "Password must be at least 6 characters"),
    role: z.enum(Object.values(USER_ROLES)),
    resumeUrl: z.url().optional(),
    companyName: string().optional(),
    website: string().url().optional(),
  }),
});

export const updateUserSchema = object({
    body: object({
        name: string().optional(),
        email: z.email("Invalid email address").optional(),
        password: string().min(6, "Password must be at least 6 characters").optional(),
        role: z.enum(Object.values(USER_ROLES)).optional(),
        resumeUrl: z.url().optional(),
        companyName: string().optional(),
        website: string().url().optional(),
    }),
});
export type CreateUserDto = TypeOf<typeof createUserSchema>["body"];
export type UpdateUserDto = TypeOf<typeof updateUserSchema>;
